import re, os, csv, textwrap
from collections import Counter, defaultdict

word_regex = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿñÑáéíóúÁÉÍÓÚüÜ']+|\d+")

class NGramModel:
    def __init__(self, project_root, max_n=3):
        self.max_n = max_n
        self.project_root = project_root
        self.sentences = []  # list of token lists (raw sentences)
        # counts stored per setting (we rebuild when settings change)
        self.ngram_counts = {n: Counter() for n in range(1, max_n+1)}
        self.history_counts = {n: Counter() for n in range(2, max_n+1)}
        self.use_boundaries = True
        self.laplace_k = 0.0  # no smoothing by default
        self.vocab = set()
        # initial load of all sentences from media/textos
        self._load_all_sentences()

    def list_corpora(self):
        base = os.path.join(self.project_root, "media", "textos")
        if not os.path.isdir(base):
            return []
        items = [f for f in os.listdir(base) if f.lower().endswith(".txt")]
        return sorted(items)


    def _sentence_split(self, text):
        parts = [p.strip() for p in re.split(r'[.!?]+|\n+', text) if p.strip()]
        return parts

    def tokenize_sentence(self, s):
        return word_regex.findall(s.lower())

    def _load_all_sentences(self):
        base = os.path.join(self.project_root, "media", "textos")
        self.sentences = []
        if not os.path.isdir(base):
            return
        for fn in sorted(os.listdir(base)):
            if not fn.lower().endswith(".txt"):
                continue
            path = os.path.join(base, fn)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                    text = fh.read()
            except Exception:
                continue
            parts = self._sentence_split(text)
            for p in parts:
                toks = self.tokenize_sentence(p)
                if toks:
                    self.sentences.append((fn, toks))  # store filename with tokens

    def train(self, corpus_filename=None, use_boundaries=True, laplace_k=0.0):
        """
        corpus_filename: if provided, train only from that file; otherwise use all files
        use_boundaries: whether to add <s> padding for n>1 and </s> at sentence end
        laplace_k: smoothing parameter (0.0 = no smoothing; >0 adds Laplace smoothing)
        """
        self.use_boundaries = use_boundaries
        self.laplace_k = float(laplace_k)
        # reset counts
        self.ngram_counts = {n: Counter() for n in range(1, self.max_n+1)}
        self.history_counts = {n: Counter() for n in range(2, self.max_n+1)}
        self.vocab = set()
        # select sentences
        if corpus_filename:
            selected = [toks for fn,toks in self.sentences if fn == corpus_filename]
        else:
            selected = [toks for fn,toks in self.sentences]
        # build counts based on use_boundaries
        for toks in selected:
            # update vocab
            for t in toks:
                self.vocab.add(t)
            # unigrams: include </s> as token representing end if boundaries used,
            # otherwise still include sentence words and a sentence-end token is optional
            if self.use_boundaries:
                for t in toks + ["</s>"]:
                    self.ngram_counts[1][(t,)] += 1
            else:
                for t in toks:
                    self.ngram_counts[1][(t,)] += 1
            # bigrams and trigrams with padding if use_boundaries
            if self.use_boundaries:
                padded2 = ["<s>"] + toks + ["</s>"]
                for i in range(len(padded2)-1):
                    self.ngram_counts[2][tuple(padded2[i:i+2])] += 1
                    self.history_counts[2][(padded2[i],)] += 1
                padded3 = ["<s>","<s>"] + toks + ["</s>"]
                for i in range(len(padded3)-2):
                    self.ngram_counts[3][tuple(padded3[i:i+3])] += 1
                    self.history_counts[3][(padded3[i],padded3[i+1])] += 1
            else:
                # no sentence padding: generate ngrams across sentence tokens only
                for i in range(len(toks)-1):
                    self.ngram_counts[2][(toks[i], toks[i+1])] += 1
                    self.history_counts[2][(toks[i],)] += 1
                for i in range(len(toks)-2):
                    self.ngram_counts[3][(toks[i], toks[i+1], toks[i+2])] += 1
                    self.history_counts[3][(toks[i], toks[i+1])] += 1
        # Add vocab size to include possible </s> token
        if self.use_boundaries:
            self.vocab.add("</s>")

    def mle_prob(self, n, history, word):
        """
        Compute MLE probability optionally with Laplace smoothing:
        P(w|h) = (C(h,w) + k) / (C(h) + k*V)
        where V is vocabulary size. For unigram, history is empty tuple.
        """
        V = max(1, len(self.vocab))
        if n == 1:
            cw = self.ngram_counts[1].get((word,), 0)
            total = sum(self.ngram_counts[1].values())
            if self.laplace_k > 0.0:
                return (cw + self.laplace_k) / (total + self.laplace_k * V), cw, total
            else:
                return (cw / total) if total>0 else 0.0, cw, total
        key = tuple(list(history) + [word])
        chw = self.ngram_counts[n].get(key, 0)
        ch = self.history_counts[n].get(tuple(history), 0)
        if self.laplace_k > 0.0:
            return (chw + self.laplace_k) / (ch + self.laplace_k * V), chw, ch
        else:
            prob = (chw/ch) if ch>0 else 0.0
            return prob, chw, ch

    def suggest_next(self, context, n=3, k=5):
        # tokenize context
        ctx_tokens = self.tokenize_sentence(context)
        for order in range(n, 0, -1):
            hist_len = order - 1
            history = tuple(ctx_tokens[-hist_len:]) if hist_len > 0 else tuple()
            candidates = []
            if order == 1:
                total = sum(self.ngram_counts[1].values())
                for (w,), c in self.ngram_counts[1].items():
                    prob = self.mle_prob(1, (), w)[0]
                    candidates.append((w, c, prob))
                ch = total
            else:
                ch = self.history_counts[order].get(tuple(history), 0)
                for (ngram), c in self.ngram_counts[order].items():
                    if ngram[:-1] == history:
                        prob = self.mle_prob(order, history, ngram[-1])[0]
                        candidates.append((ngram[-1], c, prob))
            if candidates:
                candidates = sorted(candidates, key=lambda x:(-x[2], -x[1], x[0]))
                result = []
                for w,c,prob in candidates[:k]:
                    result.append({"history":" ".join(history) if history else "<empty>", "next_word": w, "C(h,w)": c, "C(h)": ch, "P(w|h)": prob})
                return order, result
        return None, []

    def export_top_ngrams(self, out_dir, topk=200):
        os.makedirs(out_dir, exist_ok=True)
        # write top unigrams, bigrams, trigrams CSVs
        uni_path = os.path.join(out_dir, "top_unigrams.csv")
        bi_path = os.path.join(out_dir, "top_bigrams.csv")
        tri_path = os.path.join(out_dir, "top_trigrams.csv")
        with open(uni_path, "w", encoding="utf-8", newline='') as fh:
            writer = csv.writer(fh)
            writer.writerow(["token","count"])
            for (w,),c in self.ngram_counts[1].most_common(topk):
                writer.writerow([w,c])
        with open(bi_path, "w", encoding="utf-8", newline='') as fh:
            writer = csv.writer(fh)
            writer.writerow(["bigram","count"])
            for (w1,w2),c in self.ngram_counts[2].most_common(topk):
                writer.writerow([f"{w1} {w2}", c])
        with open(tri_path, "w", encoding="utf-8", newline='') as fh:
            writer = csv.writer(fh)
            writer.writerow(["trigram","count"])
            for (w1,w2,w3),c in self.ngram_counts[3].most_common(topk):
                writer.writerow([f"{w1} {w2} {w3}", c])
        return {"unigrams": uni_path, "bigrams": bi_path, "trigrams": tri_path}

    def generate_informe(self, out_path, corpus_filename=None):
        lines = []
        lines.append("# Informe del modelo de autocompletado (n-gramas MLE)\n")
        lines.append(f"- Corpus seleccionado: {corpus_filename if corpus_filename else 'Todos los archivos en media/textos/'}\n")
        lines.append(f"- Número de oraciones (estimadas): {sum(1 for _ in (self.sentences if not corpus_filename else [s for s in self.sentences if s[0]==corpus_filename]))}\n")
        lines.append(f"- Uso de fronteras de oración: {'Si' if self.use_boundaries else 'No'}\n")
        lines.append(f"- Suavizado Laplace k = {self.laplace_k}\n\n")
        lines.append("## Top 10 Unigramas\n")
        for (w,),c in self.ngram_counts[1].most_common(10):
            lines.append(f"- {w}: {c}\n")
        lines.append("\n## Top 10 Bigramas\n")
        for (w1,w2),c in self.ngram_counts[2].most_common(10):
            lines.append(f"- {w1} {w2}: {c}\n")
        lines.append("\n## Top 10 Trigramas\n")
        for (w1,w2,w3),c in self.ngram_counts[3].most_common(10):
            lines.append(f"- {w1} {w2} {w3}: {c}\n")
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.writelines(lines)
        return out_path
