from django.urls import path
from . import views

urlpatterns = [
    path('autocomplete/', views.autocomplete_view, name='autocomplete'),
    path('export/', views.export_view, name='export'),
]
