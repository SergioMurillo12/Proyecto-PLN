from django.http import JsonResponse, FileResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .ngram_model import NGramModel
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

# module-level model instance uses project root
_model = NGramModel(project_root=BASE_DIR)


@csrf_exempt
def autocomplete_view(request):
    # list available corpora for UI
    model = _model
    corpora = model.list_corpora()
    if request.method == 'GET' and request.GET.get('q') is not None:
        q = request.GET.get('q','')
        try:
            n = int(request.GET.get('n','3'))
        except:
            n = 3
        corpus = request.GET.get('corpus', '') or None
        use_boundaries = request.GET.get('boundaries', '1') == '1'
        try:
            laplace = float(request.GET.get('laplace','0.0') or 0.0)
        except:
            laplace = 0.0
        # retrain model with chosen options (fast for small corpora)
        model.train(corpus_filename=corpus, use_boundaries=use_boundaries, laplace_k=laplace)
        order, suggestions = model.suggest_next(q, n=n, k=10)
        clean = []
        for s in suggestions:
            clean.append({
                'history': str(s.get('history','')),
                'next_word': str(s.get('next_word','')),
                'C(h,w)': int(s.get('C(h,w)',0)),
                'C(h)': int(s.get('C(h)',0)),
                'P(w|h)': float(s.get('P(w|h)',0.0))
            })
        return JsonResponse({'order': order, 'suggestions': clean})
    # render UI and provide corpora list
    return render(request, 'analisis/autocomplete.html', {'corpora': corpora})

@csrf_exempt
def export_view(request):
    model = _model
    corpus = request.GET.get('corpus','') or None
    use_boundaries = request.GET.get('boundaries', '1') == '1'
    try:
        laplace = float(request.GET.get('laplace','0.0') or 0.0)
    except:
        laplace = 0.0
    model.train(corpus_filename=corpus, use_boundaries=use_boundaries, laplace_k=laplace)
    out_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'media', 'outputs')
    paths = model.export_top_ngrams(out_dir)
    informe = model.generate_informe(os.path.join(out_dir, 'informe.md'), corpus_filename=corpus)
    return JsonResponse({'paths': paths, 'informe': informe})
