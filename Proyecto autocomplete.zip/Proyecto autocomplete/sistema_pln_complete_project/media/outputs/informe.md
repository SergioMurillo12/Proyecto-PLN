# Informe del modelo de autocompletado (n-gramas MLE)
- Corpus seleccionado: ciencia.txt
- Número de oraciones (estimadas): 3
- Uso de fronteras de oración: Si
- Suavizado Laplace k = 1.0

## Top 10 Unigramas
- la: 3
- </s>: 3
- el: 2
- ciencia: 1
- es: 1
- conjunto: 1
- de: 1
- conocimientos: 1
- sistemáticos: 1
- sobre: 1

## Top 10 Bigramas
- <s> la: 2
- la ciencia: 1
- ciencia es: 1
- es el: 1
- el conjunto: 1
- conjunto de: 1
- de conocimientos: 1
- conocimientos sistemáticos: 1
- sistemáticos sobre: 1
- sobre la: 1

## Top 10 Trigramas
- <s> <s> la: 2
- <s> la ciencia: 1
- la ciencia es: 1
- ciencia es el: 1
- es el conjunto: 1
- el conjunto de: 1
- conjunto de conocimientos: 1
- de conocimientos sistemáticos: 1
- conocimientos sistemáticos sobre: 1
- sistemáticos sobre la: 1
